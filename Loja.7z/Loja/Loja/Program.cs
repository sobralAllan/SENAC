﻿using System;

namespace Loja
{
    class Program
    {
        //Classe responsável por criar um produto na memória
        public class Produto
        {
            //Declarando Atributos - Variáveis 
            public string nome;
            public int codigo;
            public double preco;
            public string fornecedor;
            public string msg;
            public int idade;
            public DateTime data;
            //Método Construtor
            public Produto()
            {
                nome       = "";
                codigo     = 0;
                preco      = 0.00;
                fornecedor = "";
            }//fim do construtor 

            //Métodos de Acesso Gets e Sets
            public string ModificarNome
            {
                get
                {
                    return nome;//retorna o conteúdo de uma variável 
                }
                set
                {
                    nome = value;
                }
            }//fim do modificarNome
            public int ModificarCodigo
            {
                get
                {
                    return codigo;//retorna o conteúdo de uma variável 
                }
                set
                {
                    codigo = value;
                }
            }//fim do modificarCodigo
            public double ModificarPreco
            {
                get
                {
                    return preco;//retorna o conteúdo de uma variável 
                }
                set
                {
                    preco = value;
                }
            }//fim do modificarPreco
            public string ModificarFornecedor
            {
                get
                {
                    return fornecedor;//retorna o conteúdo de uma variável 
                }
                set
                {
                    fornecedor = value;
                }
            }//fim do modificarFornecedor
            public int ModificarIdade
            {
                get
                {
                    return idade;
                }
                set
                {
                    idade = value;
                }
            }

            public DateTime ModificarData
            {
                get
                {
                    return data;
                }
                set
                {
                    this.data = value;
                }
            }

            //Métodos Ações
            public string Mensagem()
            {
                ModificarFornecedor = "Jão";
                ModificarPreco = 30.50;
                ModificarNome = "Camiseta do Mário";
                ModificarCodigo = 1;
                msg = "Código: "       + ModificarCodigo + 
                      "\nNome: "       + ModificarNome   +
                      "\nPreço: "      + ModificarPreco  + 
                      "\nFornecedor: " + ModificarFornecedor;
                return msg;
            }//fim da mensagem
        }//fim da classe produto

        //Classe Vendedor
        public class Vendedor
        {
            //Atributos de Vendedor
            public string nome;
            public DateTime dtNascimento;
            public int CPF;
            public string endereco;
            public string categoria; //Vendedor A ou B
            public string sexo;
            public double salario;
            public string mensagem;

            //Método Construtor
            public Vendedor()
            {
                this.nome = "";
                this.CPF = 0;
                this.salario = 0;
                this.endereco = "";
                this.categoria = "";
                this.sexo = "";
            }
            //Sobrecarga do construtor com parâmetros
            public Vendedor(string nome, DateTime dtNascimento, int CPF,
                            string endereco, string categoria, string sexo, 
                            double salario)
            {
                this.nome = nome;
                this.dtNascimento = dtNascimento;
                this.CPF = CPF;
                this.salario = salario;
                this.endereco = endereco;
                this.categoria = categoria;
                this.sexo = sexo;
            }//fim do construtor de vendedor

            //Construção de métodos modificadores e de consulta
            public string ConsultaNome
            {
                get
                {
                    return nome;
                }
                set
                {
                    nome = value;
                }
            }

            public DateTime ConsultaData
            {
                get
                {
                    return dtNascimento;
                }
                set
                {
                    dtNascimento = value;
                }
            }

            public int ConsultaCPF
            {
                get
                {
                    return CPF;
                }
                set
                {
                    CPF = value;
                }
            }

            public string ConsultaEndereco
            {
                get
                {
                    return endereco;
                }
                set
                {
                    endereco = value;
                }
            }

            public string ConsultaCategoria
            {
                get
                {
                    return categoria;
                }
                set
                {
                    categoria = value;
                }
            }

            public string ConsultaSexo
            {
                get
                {
                    return sexo;
                }
                set
                {
                    sexo = value;
                }
            }

            public double ConsultaSalario
            {
                get
                {
                    return salario;
                }
                set
                {
                    salario = value;
                }
            }
            //Método para calcular o salario
            public void CalcularSalario(double totalVenda)
            {
                ConsultaSalario = (totalVenda * 0.10) + (40 * 30);
            }


            //Método para mostrar o conteúdo de cada variável
            public string Imprimir()
            {
                mensagem = "Nome: " + ConsultaNome +
                           "\nNascimento: " + ConsultaData +
                           "\nCPF: " + ConsultaCPF +
                           "\nEndereço: " + ConsultaEndereco +
                           "\nCategoria: " + ConsultaCategoria +
                           "\nSexo: " + ConsultaSexo +
                           "\nSalário: " + ConsultaSalario;
                return mensagem;
            }
        }//Fim da Classe Vendedor



        /*Método Principal de uma classe, 
        por meio dele que todo o conteúdo do programa é mostrado.*/
        static void Main(string[] args)
        {
            //Instanciando a variável.
            Vendedor vend = new Vendedor();
            Console.WriteLine("Escreva Seu Nome: ");
            vend.ConsultaNome = Console.ReadLine();

            Console.WriteLine("Digite seu CPF: ");
            vend.ConsultaCPF = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Digite sua data de nascimento: ");
            vend.ConsultaData = Convert.ToDateTime(Console.ReadLine());

            vend.ConsultaCategoria = Console.ReadLine();

            vend.ConsultaSexo = Console.ReadLine();

            vend.ConsultaEndereco = Console.ReadLine();

            Console.WriteLine("O quanto você vendeu?");
            vend.CalcularSalario(Convert.ToDouble(Console.ReadLine()));

            Console.WriteLine("Confirme seus dados: " + "\n" + vend.ConsultaData + "\n" + vend.ConsultaCategoria);












            /*
            //Escrevendo o valor inicial da data e em seguida coletando o dado. 
            Console.WriteLine(prod.ModificarData);
            prod.ModificarData = Convert.ToDateTime(Console.ReadLine());

            //ToShortDateString: Função para Trazer a parte de data. 
            Console.WriteLine(prod.ModificarData.ToShortDateString());

            //Solicitando a digitação da idade de um funcionário.
            Console.WriteLine("Escreva a idade de um funcionário: ");
            prod.ModificarIdade = Int32.Parse(Console.ReadLine());

            //Escrevendo a idade do funcionário.
            Console.WriteLine("A sua idade é: " + prod.ModificarIdade + " Anos");
            Console.ReadLine();
            */
        }
    }
}
