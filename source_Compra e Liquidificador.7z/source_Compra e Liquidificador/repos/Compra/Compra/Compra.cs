﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compra
{
    public class Produto
    {

        private string descricao;
        public int codigo;
        public double preco;
        public int quantidade;
        public string msg;

        //Método construtor
        public Produto(int codigo, string descricao, double preco, int quantidade)
        {
            this.Descricao1 = descricao;
            this.codigo = codigo;
            this.preco = preco;
            this.quantidade = quantidade;
        }

        //Métodos get e set para acesso aos dados
        public string Descricao
        {
            get
            {
                return Descricao1;
            }
            set
            {
                this.Descricao1 = value;
            }
        }

        public int Codigo
        {
            get
            {
                return codigo;
            }
            set
            {
                this.codigo = value;
            }
        }
        public double Preco
        {
            get
            {
                return preco;
            }
            set
            {
                this.preco = value;
            }
        }
        public int Quantidade
        {
            get
            {
                return quantidade;
            }
            set
            {
                this.quantidade = value;
            }
        }

        public global::System.String Descricao1 { get => descricao1; set => descricao1 = value; }
        public global::System.String Descricao11 { get => descricao1; set => descricao1 = value; }
        //fim dos métodos gets e sets
    }//fim da classe produto

    public class Cliente
    {

        public long cpf;
        public string nome;
        public double credito;
        public string endereco;

        //Método construtor
        public Cliente(long cpf, string nome, double credito, string endereco)
        {
            this.cpf = cpf;
            this.nome = nome;
            this.credito = credito;
            this.endereco = endereco;
        }

        //Métodos gets e sets
        public long Cpf
        {
            get
            {
                return cpf;
            }
            set
            {
                this.cpf = value;
            }
        }
        public string Nome
        {
            get
            {
                return nome;
            }
            set
            {
                this.nome = value;
            }
        }
        public double Credito
        {
            get
            {
                return credito;
            }
            set
            {
                this.credito = value;
            }
        }
        public string Endereco
        {
            get
            {
                return endereco;
            }
            set
            {
                this.endereco = value;
            }
        }//fim dos métodos gets e sets
    }//fim da classe cliente

    public class Pedido
    {
        public int codigo;
        public double precoFinal;
        public string produto;

        Produto prod = new Produto(001, "Arroz", 10.00, 100);
        Cliente clie = new Cliente(1155554677, "João", 2500.50, "Rua Pereira Barreto, 300, Santo André");

        public Pedido(double precoFinal, string produto)
        {
            this.codigo = 0;
            this.precoFinal = prod.Preco * prod.Quantidade;
            this.produto = prod.Descricao;
        }//fim do construtor

        //métodos gets e set
        public int Codigo
        {
            get
            {
                return codigo;
            }
            set
            {
                this.codigo = value;
            }
        }
        public double PrecoFinal
        {
            get
            {
                return precoFinal;
            }
            set
            {
                this.precoFinal = value;
            }
        }
        public string Produto
        {
            get
            {
                return produto;
            }
            set
            {
                this.produto = produto;
            }
        }//fim dos métodos gets e sets 

        //Método responsável por mostrar o resultado em tela
        public void Mensagem()
        {
            msg         = "Pedido"    + Codigo     + "\n\n" +
                          "Nome: "    + clie.Nome  + "\n"   +
                          "Produto: " + Produto    + "\n"   +
                          "Total: "   + PrecoFinal + "\n\n" +
                                   "Obrigado pela Preferência!");
        }

    }//fim da classe pedido 
    public static void main(String[] args)
    {
        Console.Write(msg);
    }
}//fim do namespace
