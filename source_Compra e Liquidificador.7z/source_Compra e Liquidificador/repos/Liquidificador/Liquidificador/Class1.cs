﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Liquidificador
{
    public class Liquidificador
    {
        public int velocidade;
        public string vAtual;

        public Liquidificador(int velocidade){
            this.velocidade = velocidade;
            this.vAtual = "0";
        }
        //Mostrar mensagem



        //Consulta e alteração da variável velocidade 
        public int alteracaoVelocidade
        {
            get
            {
                return velocidade;
            }
            set
            {
                this.velocidade = value;
            }
        }//fim da alteracao velocidade 

        //Consulta de modificação da variável valor Atual
        public string alteracaoVAtual
        {
            get
            {
                return vAtual;
            }
            set
            {
                this.vAtual = value;
            }
        }//fim da alteração de valor atual

    }//fim da classe 
}//fim do namespace
