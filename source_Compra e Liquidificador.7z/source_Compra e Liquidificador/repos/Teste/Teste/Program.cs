﻿using System;
using System.IO;

namespace Teste
{
    class Carro
    {
        public int    anoFab;
        public int    cnh;
        public String mensagem;
        public Carro()
        {
            AnoFabricacao = anoFab;
            DadoCNH = cnh;
        }

        public int AnoFabricacao
        {
            get{
                return this.anoFab;
            }
            set{
                this.anoFab = value;
            }
        }

        public int DadoCNH
        {
            get
            {
                return this.cnh;
            }
            set
            {
                this.cnh = value;
            }
        }
        
        public String Velocidade()
        {
            mensagem = "Os dados da CNH são: \n" + DadoCNH + "\n" + AnoFabricacao;
            return mensagem;
        }

        static void Main(string[] args)
        {
            Carro car = new Carro();

            Console.WriteLine(car.Velocidade());
            car.AnoFabricacao = int.Parse(Console.ReadLine());
            Console.Write(car.AnoFabricacao);

        }
    }
}
