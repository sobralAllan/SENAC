﻿using System;

namespace Loja
{
    class Program
    {
        //Classe responsável por criar um produto na memória
        public class Produto
        {
            //Declarando Atributos - Variáveis 
            public string nome;
            public int codigo;
            public double preco;
            public string fornecedor;
            public string msg;
            //Método Construtor
            public Produto()
            {
                nome       = "";
                codigo     = 0;
                preco      = 0.0;
                fornecedor = "";
            }//fim do construtor 

            //Métodos de Acesso Gets e Sets
            public string ModificarNome
            {
                get
                {
                    return nome;//retorna o conteúdo de uma variável 
                }
                set
                {
                    nome = value;
                }
            }//fim do modificarNome
            public int ModificarCodigo
            {
                get
                {
                    return codigo;//retorna o conteúdo de uma variável 
                }
                set
                {
                    codigo = value;
                }
            }//fim do modificarCodigo
            public double ModificarPreco
            {
                get
                {
                    return preco;//retorna o conteúdo de uma variável 
                }
                set
                {
                    preco = value;
                }
            }//fim do modificarPreco
            public string ModificarFornecedor
            {
                get
                {
                    return fornecedor;//retorna o conteúdo de uma variável 
                }
                set
                {
                    fornecedor = value;
                }
            }//fim do modificarFornecedor

            //Métodos Ações
            public string Mensagem()
            {
                ModificarFornecedor = "Jão";
                ModificarPreco = 30.50;
                ModificarNome = "Camiseta do Mário";
                ModificarCodigo = 1;
                msg = "Código: "       + ModificarCodigo + 
                      "\nNome: "       + ModificarNome   +
                      "\nPreço: "      + ModificarPreco  + 
                      "\nFornecedor: " + ModificarFornecedor;
                return msg;
            }//fim da mensagem
        }//fim da classe produto




        /*Método Principal de uma classe, 
        por meio dele que todo o conteúdo do programa é mostrado.*/
        static void Main(string[] args)
        {
            Produto prod = new Produto();
            Console.WriteLine(prod.Mensagem());
            Console.ReadLine();

        }
    }
}
