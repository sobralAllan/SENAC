﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Compra
{
   
    class Compra
    {
        public string produto;
        public double valor;
        public int quantidade;
        public string msg;
        
        public Compra(string produto, double valor, int quantidade)
        {
            this.produto    = produto;
            this.valor      = valor;
            this.quantidade = quantidade;
            this.msg = "";

        }//Método construtor da classe Compra

        public string mensagem()
        {
            return msg = "Produto: "    + produto + 
                         "\nValor: "      + valor   +
                         "\nQuantidade: " + quantidade;
        }

        public void texto(string palavra)
        {
            this.msg = palavra;
        }
        public static void Main(string[] args)
        {
            Console.WriteLine("Informe o  produto");
            Compra cmp = new Compra("Arroz", 30.3, 2);
            cmp.texto(Console.ReadLine());
            Console.WriteLine(cmp.mensagem());            
        }//fim do método main
    }//fim da classe 
}//fim do namespace
